from flask import Flask, render_template, request, flash
import openai

openai.api_key = open("key.txt", "r").read().strip('\n')
message_history = []

def chat(inp, role = "user"):
    message_history.append({"role":role,"content":inp})
    completion = openai.ChatCompletion.create(model="gpt-3.5-turbo", messages=message_history)
    
    reply_content = completion["choices"][0]["message"]["content"]

    print(reply_content)

    message_history.append({"role":"assistant","content":reply_content})
    return reply_content

app = Flask(__name__)
app.secret_key = "something"

@app.route("/")
def index():
	return render_template("index.html")
history = []

for m in history:
	print(m)
@app.route("/response", methods=['POST', 'GET'])
def response():
	history.append(str(request.form['name_input']))
	history.append(chat(str(request.form['name_input'])))
	for m in history:
		flash(m)
	return render_template("index.html")

@app.route("/clear", methods=['POST', 'GET'])
def clear():
	history.clear()
	message_history.clear()
	return render_template("index.html")





	
    
    
	

app.run(host="0.0.0.0",port = 80)